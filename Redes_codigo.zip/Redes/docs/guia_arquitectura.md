# Guía de arquitectura — Laboratorio 3

Esta guía está pensada para alguien que nunca vio el proyecto. Primero explica qué hace cada carpeta y cada archivo, y después recorre paso a paso, en el orden real en que ocurre, todo el flujo desde que se prende un router hasta que un mensaje va y vuelve entre el ATM y el BANK.

Si algún término (TTL, hops, LSA, síndrome, etc.) no queda claro, hay un glosario al final.

## 1. Mapa de carpetas

```
config/       configuración de la topología (quién es vecino de quién)
docs/         documentación del protocolo y de la arquitectura
runtime/      generado en tiempo de ejecución (tablas CSV, seq persistido) — no se versiona
src/
  main.py     arranca un router
  comun/      código que usan tanto el plano de control como el de datos
  control/    plano de control: Link State
  datos/      plano de datos: reenvío de mensajes
  endpoints/  procesos que NO son routers (el cajero y el banco)
tests/        pruebas unitarias, un archivo por módulo de src/
```

La regla para decidir dónde va cada cosa nueva: si lo usan router y forwarding por igual, va en `comun/`; si es sobre aprender la topología y calcular rutas, va en `control/`; si es sobre mover un mensaje ya con ruta calculada, va en `datos/`; si el proceso no es un router (no participa en Link State), va en `endpoints/`.

## 2. Qué hace cada archivo

### `config/topologia.json`

La única fuente de verdad de la red: para cada router (`A`–`I`) declara su IP, puerto y sus vecinos con el costo de cada enlace. También declara los `endpoints` (`ATM`, `BANK`), cada uno con su propia IP/puerto y el nombre del router que le sirve de `gateway`. Todos los routers cargan el archivo completo, no solo su propia entrada — así cualquiera puede resolver "¿cuál es el gateway de BANK?" sin tener que preguntarle a nadie.

### `src/comun/` — compartido

| Archivo | Qué hace |
| --- | --- |
| `configuracion.py` | Lee `topologia.json` y expone funciones de consulta: `config_nodo` (config de un router), `direccion_router` (IP/puerto de un router), `config_endpoint` (config de ATM/BANK). |
| `transporte.py` | La capa de sockets, sin saber nada del protocolo. `ServidorLineas` escucha conexiones TCP y le pasa cada línea completa (separada por `\n`) a un callback. `enviar_trama(ip, puerto, texto)` abre una conexión, manda una línea y la cierra. |
| `protocolo.py` | El framing: decide si una trama va como `J|<json>` (control, siempre plano) o `H|<bits>` (datos, con Hamming). `crear_trama`/`leer_trama` son las dos funciones que arman y desarman una trama. |
| `hamming.py` | Hamming(7,4) de verdad: `codificar_bytes`/`decodificar_bits` convierten bytes UTF-8 a/desde bits corregibles, detectando y arreglando un bit dañado por cada bloque de 7. |

### `src/control/` — cómo el router aprende la red

| Archivo | Qué hace |
| --- | --- |
| `router.py` | El corazón del programa. La clase `Router` arranca los hilos de HELLO, vigilancia de vecinos y reemisión periódica de LSA; procesa toda trama que le llega (`procesar_trama`) y decide si es HELLO, LSA, o un mensaje de datos (que delega al `Reenviador`). |
| `dijkstra.py` | Solo matemáticas: dado un grafo (la LSDB) y un origen, `caminos_mas_cortos` calcula la distancia mínima a cada nodo, y `siguiente_salto` reconstruye cuál es el primer salto de esa ruta. No sabe nada de sockets ni de JSON. |

### `src/datos/` — mover un mensaje ya con ruta calculada

| Archivo | Qué hace |
| --- | --- |
| `forwarding.py` | La clase `Reenviador`. Recibe un sobre de datos ya decodificado, valida TTL/hops, decide a quién mandárselo (consultando el CSV de rutas, o el gateway de un endpoint) y lo reenvía. No le importa qué dice el `payload`. |

### `src/endpoints/` — procesos que no son routers

| Archivo | Qué hace |
| --- | --- |
| `atm_cliente.py` | El cajero. Se conecta a su gateway (router A), muestra un menú (login, retirar, mandar mensaje, salir) y escucha en su propio socket las respuestas que le llegan de vuelta. |
| `banco_servidor.py` | El banco. Escucha en su propio socket (a través de su gateway, router E), procesa `login`/`withdraw`/`logout` contra una lista de cuentas de prueba, y contesta por el mismo camino. |

### `src/main.py`

El único punto de entrada para levantar un router: `python src/main.py A` carga la topología, crea un `Router("A", ...)` y lo arranca. No tiene lógica propia, solo conecta las piezas.

### `tests/`

Un archivo de test por módulo: `test_dijkstra.py`, `test_hamming.py`, `test_protocolo.py`, `test_forwarding.py`. No hay test de `router.py` ni de los endpoints porque esos dependen de sockets reales corriendo en paralelo — se prueban a mano (ver §4).

### `docs/`

`protocolo.md` es el contrato formal (el que comparten las tres parejas antes de conectar por Tailscale): formato exacto de HELLO, LSA, sobre de datos y Hamming. `ricardo.md` documenta cómo quedó implementado el plano de datos. Este archivo (`guia_arquitectura.md`) es la vista de conjunto.

## 3. Cómo funciona todo, paso a paso

### Fase 0 — Arranque de un router

`python src/main.py A` → `main.py` llama `Router("A", topologia).iniciar()`.

`Router.__init__` (`control/router.py:21`) lee su propia config (`config_nodo`), guarda sus vecinos con costo, y arranca vacío: `vecinos_activos = set()` (todavía no confía en ninguno) y `lsdb = {}` (todavía no sabe nada del resto de la red).

`iniciar()` (línea 50): abre el socket servidor, lanza tres hilos daemon (`_ciclo_hello`, `_vigilar_vecinos`, `_ciclo_lsa`) que corren para siempre en paralelo, y emite su primer LSA (vacío, porque aún no confirmó vecinos).

### Fase 1 — Descubrir vecinos (HELLO)

`_ciclo_hello` (línea 80) manda cada 5s un `{"type":"HELLO","from":"A"}` a cada vecino *configurado*, sin esperar respuesta.

Cuando A recibe el HELLO de B por primera vez, `_procesar_hello` (línea 88) agrega a B a `vecinos_activos` y dispara `_emitir_lsa()` — recién ahí B "existe" para A.

`_vigilar_vecinos` (línea 98) corre cada 1s y saca de `vecinos_activos` a cualquiera del que no haya llegado HELLO en 15s (`TIEMPO_CAIDA`), y también re-emite el LSA cuando eso pasa.

### Fase 2 — Anunciar y difundir (LSA + flooding)

`_emitir_lsa` (línea 124): sube el `seq`, arma `{"type":"LSA","origin":"A","links":{...},"ttl":8}` con los vecinos activos actuales, actualiza su propia entrada en la LSDB, recalcula rutas, y lo manda a todos sus vecinos activos (`_inundar`, línea 149).

Cuando un router recibe un LSA ajeno, `_procesar_lsa` (línea 135) lo descarta si el `seq` no es más nuevo que el que ya tenía de ese `origin`; si es nuevo, actualiza su LSDB, recalcula, y lo reenvía a sus propios vecinos activos (menos a quien se lo mandó), bajando el TTL. Así, sin que A sepa nada de I, D o E directamente, el LSA de A termina llegando a todos por flooding.

**Además**, `_ciclo_lsa` (línea 108, agregado tras encontrar un bug de convergencia) reemite el LSA propio cada 20s aunque no haya cambiado nada — así, si una copia se perdió en tránsito en algún momento (una conexión TCP falló y `_inundar` no reintenta), la red se autorepara sola en el siguiente ciclo, en vez de quedar con una vista incompleta para siempre.

### Fase 3 — Calcular rutas (Dijkstra) y escribir el CSV

Cada vez que cambia la LSDB, `_recalcular` (línea 155) llama a `dijkstra.caminos_mas_cortos(lsdb, "A")` y sobrescribe `runtime/A_tabla_enrutamiento.csv` con una fila por destino: `destino,siguiente_salto,costo,ip,puerto`.

### Fase 4 — Red convergida

Después de unos segundos, todos los routers tienen la misma vista del grafo completo y sus CSV dejan de cambiar. Los hilos de HELLO, vigilancia y refresco de LSA **nunca paran** — quedan listos para detectar una caída o reparar una pérdida en cualquier momento.

### Fase 5 — El ATM se conecta

`atm_cliente.py` no es un `Router`: arranca su propio `ServidorLineas` (para recibir respuestas) y pide tarjeta/PIN. Cada operación (`Cajero.consultar`, en el archivo) arma un sobre:

```json
{"type":"message","from":"ATM","to":"BANK","ttl":16,"hops":["ATM"],"payload":{"action":"login","data":{...}}}
```

lo serializa con `crear_trama(mensaje, con_hamming=...)` (según el flag `--hamming`) y lo manda directo a su gateway (router A) con `enviar_trama`. Como cada envío es una conexión de una sola línea (no hay respuesta en la misma conexión), el ATM se queda esperando en una `queue.Queue` a que su propio listener reciba algo.

### Fase 6 — El mensaje viaja salto a salto

A recibe la trama, `procesar_trama` la decodifica y, como `type == "message"`, se la pasa a `self.reenviador.procesar(mensaje, usa_hamming)` (`datos/forwarding.py`).

`Reenviador.procesar`: valida el sobre, revisa que A no esté ya en `hops` y que TTL no sea 0, resuelve el siguiente salto (`_resolver_siguiente_salto`) y reenvía. Para un destino `BANK`, como A no es su gateway, busca en su propio CSV la fila hacia `E` (el gateway de BANK) y le manda la trama al router que le sigue en esa ruta (I). Esto se repite en cada salto — **cada router decide solo con su propio CSV**, nadie conoce la ruta completa de antemano: A → I → D → E.

### Fase 7 — Entrega al BANK

E, que sí es el gateway de BANK, ve en `_resolver_siguiente_salto` que el `gateway` del endpoint es él mismo, así que en vez de seguir buscando en el CSV le manda la trama directo a la IP/puerto del proceso BANK.

`banco_servidor.py` la recibe en su propio `ServidorLineas`, decodifica el `payload`, y `Banco._procesar` ejecuta la operación (`login`, `withdraw`, `logout`) contra las cuentas de prueba, guardando la sesión en memoria indexada por `from` (`"ATM"`).

### Fase 8 — La respuesta vuelve

BANK arma un sobre nuevo con `from: "BANK"`, `to: "ATM"`, y lo manda a su propio gateway (E). El mensaje hace el camino inverso salto a salto (E → D → I → A), cada router resolviendo de nuevo con su propio CSV, hasta que A —gateway de ATM— se lo entrega directo al proceso ATM, cuyo listener lo mete en la cola y despierta al `consultar()` que estaba esperando.

### Fase 9 — Tolerancia a fallos (ya corriendo en bucle desde la fase 0)

Si se cae un router, sus vecinos dejan de recibir HELLO, a los 15s lo sacan de `vecinos_activos`, reemiten su LSA sin ese enlace, y eso se propaga por flooding — todos recalculan y regeneran su CSV. Si vuelve a levantarse, reengancha solo desde la fase 1.

## 4. Cómo probarlo

```powershell
# Plano de control + datos con tests automáticos
$env:PYTHONPATH = "src"
python -m unittest discover -s tests -v

# Flujo completo a mano (9 terminales para los routers + 2 para los endpoints)
python src/main.py A   # ...hasta I
python src/endpoints/banco_servidor.py
python src/endpoints/atm_cliente.py            # o con --hamming
```

## 5. Glosario rápido

- **Vecino**: router con conexión directa (definido en `topologia.json`).
- **Costo**: peso de un enlace; Dijkstra minimiza la suma de costos, no la cantidad de saltos.
- **Salto / hop**: cada vez que un mensaje pasa de un router a otro.
- **Gateway**: el router al que se conecta un endpoint (ATM/BANK) para entrar a la red.
- **HELLO**: "sigo vivo", cada 5s, entre vecinos directos, no se reenvía.
- **LSA**: anuncio de "estos son mis vecinos y su costo"; se propaga por flooding a toda la red.
- **`origin` vs `from`**: `origin` es quién es dueño del LSA (nunca cambia); `from` es quién me lo mandó a mí en este salto (cambia en cada reenvío).
- **`seq`**: número creciente por origin, para saber cuál LSA es más nuevo y descartar duplicados/viejos.
- **TTL**: contador que baja en cada salto; al llegar a 0 se deja de reenviar (evita bucles infinitos).
- **LSDB**: la base de datos local de todos los LSA recibidos; con eso se arma el grafo completo de la red.
- **Siguiente salto**: el vecino inmediato al que hay que mandarle un mensaje para acercarlo al destino final (lo que guarda el CSV).
- **`hops`** (en el sobre de datos): lista de routers por los que ya pasó ese mensaje, para evitar ciclos.
- **`J|` / `H|`**: prefijo de una trama; `J|` es JSON plano (siempre en HELLO/LSA), `H|` son bits codificados con Hamming(7,4) (solo en datos, red ya convergida).
- **Nibble**: mitad de un byte (4 bits); Hamming(7,4) codifica un nibble en un bloque de 7 bits.
- **Síndrome**: número calculado al decodificar que indica cuál bit (si alguno) está mal y hay que corregir.
